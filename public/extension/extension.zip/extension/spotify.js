jQuery.noConflict();
jQuery(document).ready(function(){
    setTimeout(function() {
        jQuery('#item-action').eq(0).click();
    }, 2500);
});